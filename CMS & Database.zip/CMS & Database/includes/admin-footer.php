<footer id="footer-bar" class="row">
    <p id="footer-copyright" class="col-xs-12">
        Powered by 24/7 Taxi.
    </p>
</footer>
