<?php
if($query) {
    print_r($query);
}
?>