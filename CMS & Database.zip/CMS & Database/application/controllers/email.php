<html><head><meta content="text/html; charset=utf-8" http-equiv="Content-Type"><meta charset="UTF-8"></head><body>Noqil:<table style="background-color: #00a7d0; color: #0a0a0a; border: groove; border: #1a0802; font-size: medium; width: 500px;">
    <tr>
        <td><img src="http://v1technology.co.uk/demo/naqil/naqilcom/Source/upload/logo.png" style="height:100px; width:250px" /></td>
    </tr>
    <tr>
        <td>Username</td>
        <td>'.$email.'</td>
    </tr>
    <tr>
        <td>Password</td>
        <td>'.$pass.'</td>
    </tr>
</table>
<table style="background-color: #00a7d0; color: #0a0a0a; border: groove; border: #1a0802; font-size: medium; width: 500px;">
    <tr>
        <td>
            <p>Thanks for signing up! Your account has been created, you can login with your credentials you have activated your account</p>
        </td></tr>
</table></body></html>